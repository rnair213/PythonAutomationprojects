from configparser import ConfigParser


def readconfig(section, key):
    config = ConfigParser()
    config.read("config.ini")
    print(config.sections())
    return config.sections()


#print(readconfig("Url", "TestSite_URL"))
